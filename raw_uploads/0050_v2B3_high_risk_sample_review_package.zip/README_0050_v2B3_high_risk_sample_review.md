# 0050 v2-B3 High Risk Sample Review

## 用途
研究 v2-B3 final signal candidate 的剩餘高風險樣本。

## 建議輸入
優先上傳 `0050_v2B3_final_stratified_review_outputs.xlsx`，程式會讀取 `Parsed_B3_Events`。
也可上傳 v2-B3 TradingView raw CSV，程式會解析 ENTRY / EXIT 字串。

## 輸出
`0050_v2B3_high_risk_sample_review_outputs.xlsx`

## 重點
這不是 v2-C，不是主策略版本；這是 Future Work / Execution Research，用來判斷剩餘弱點是訊號、成本、出場、重複訊號衰減，還是市場狀態問題。
