# -*- coding: utf-8 -*-
"""
0050 v2-B3 High Risk Sample Review - READY VERSION

請在 Colab 執行本程式，並且只上傳：
UPLOAD_THIS_TO_COLAB__v2B3_Parsed_B3_Events_223.csv

不要上傳 TradingView raw CSV，也不要上傳前一次 high risk output。

輸出：
0050_v2B3_high_risk_sample_review_outputs_READY.xlsx
"""

import pandas as pd
import numpy as np
from IPython.display import display
from google.colab import files

# =========================
# 0. Parameters
# =========================

TICK_SIZE = 0.05
COST_001 = 0.01
COST_002 = 0.02
SLIP_025_TICK_ROUNDTRIP = 0.25 * TICK_SIZE * 2
SLIP_05_TICK_ROUNDTRIP = 0.5 * TICK_SIZE * 2
OUTPUT_FILE = "0050_v2B3_high_risk_sample_review_outputs_READY.xlsx"

print("請上傳這個檔案：UPLOAD_THIS_TO_COLAB__v2B3_Parsed_B3_Events_223.csv")
uploaded = files.upload()
file_name = list(uploaded.keys())[0]
print("Loaded:", file_name)

# =========================
# 1. Load and validate
# =========================

df = pd.read_csv(file_name, encoding="utf-8-sig")
print("Raw shape:", df.shape)
print("Columns:", df.columns.tolist())

# 必要欄位檢查
required_cols = [
    "trade_number", "entry_datetime", "exit_datetime", "entry_year",
    "entry_time_hhmm", "base_pnl_twd", "session_block", "data_split",
    "exit_reason", "signal_count_today",
    "entry_relative_deviation", "tw50_return_5m",
    "realized_vol_10bar", "deviation_slope_1bar"
]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"缺少必要欄位：{missing}。請確認你上傳的是我整理好的 UPLOAD_THIS_TO_COLAB__v2B3_Parsed_B3_Events_223.csv")

if len(df) != 223:
    raise ValueError(f"這份資料應該是 223 筆 v2-B3 交易，但目前是 {len(df)} 筆。你很可能又上傳錯檔。")

# 數值欄位轉型
numeric_cols = [
    "base_pnl_twd", "entry_year", "entry_price", "exit_price",
    "pnl_cost_001", "pnl_cost_002", "pnl_cost_0035",
    "holding_minutes", "mfe_twd", "mae_twd",
    "entry_relative_deviation", "volume_ratio_at_entry",
    "deviation_slope_1bar", "deviation_slope_3bar",
    "etf_return_5m", "etf_return_15m",
    "tw50_return_5m", "tw50_return_15m",
    "realized_vol_10bar", "minutes_since_open", "minutes_to_close",
    "signal_count_today", "exit_relative_deviation", "bars_held"
]
for c in numeric_cols:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")

df["entry_datetime"] = pd.to_datetime(df["entry_datetime"], errors="coerce")
df["exit_datetime"] = pd.to_datetime(df["exit_datetime"], errors="coerce")

# 統一 pnl 欄位
# base_pnl_twd 是未扣成本損益，v2-B3 正確總和應約 7.80
df["pnl_no_cost"] = df["base_pnl_twd"]
df["pnl_cost_001_recalc"] = df["pnl_no_cost"] - COST_001
df["pnl_cost_002_recalc"] = df["pnl_no_cost"] - COST_002
df["pnl_slip_025tick"] = df["pnl_no_cost"] - SLIP_025_TICK_ROUNDTRIP
df["pnl_slip_05tick"] = df["pnl_no_cost"] - SLIP_05_TICK_ROUNDTRIP

print("Validation check:")
print("trades:", len(df))
print("net pnl no cost:", round(df["pnl_no_cost"].sum(), 4))

if abs(df["pnl_no_cost"].sum() - 7.80) > 0.2:
    print("警告：未扣成本總 PnL 不接近 7.80，請確認資料版本。")

# =========================
# 2. Performance functions
# =========================

def profit_factor(pnl):
    pnl = pd.to_numeric(pnl, errors="coerce").dropna()
    gp = pnl[pnl > 0].sum()
    gl = pnl[pnl < 0].sum()
    if gl < 0:
        return gp / abs(gl)
    if gp > 0 and gl == 0:
        return np.inf
    return np.nan


def max_drawdown(pnl):
    pnl = pd.to_numeric(pnl, errors="coerce").fillna(0)
    cum = pnl.cumsum()
    return (cum.cummax() - cum).max()


def perf_summary(data, pnl_col="pnl_no_cost", group_cols=None):
    def calc(x):
        pnl = pd.to_numeric(x[pnl_col], errors="coerce").dropna()
        n = len(pnl)
        if n == 0:
            return pd.Series({
                "trades": 0, "wins": 0, "losses": 0, "flats": 0,
                "win_rate": np.nan, "loss_rate": np.nan,
                "net_pnl": 0.0, "avg_pnl": np.nan, "median_pnl": np.nan,
                "gross_profit": 0.0, "gross_loss": 0.0, "profit_factor": np.nan,
                "max_single_profit": np.nan, "max_single_loss": np.nan,
                "estimated_max_drawdown": np.nan
            })
        gp = pnl[pnl > 0].sum()
        gl = pnl[pnl < 0].sum()
        return pd.Series({
            "trades": n,
            "wins": int((pnl > 0).sum()),
            "losses": int((pnl < 0).sum()),
            "flats": int((pnl == 0).sum()),
            "win_rate": (pnl > 0).mean(),
            "loss_rate": (pnl < 0).mean(),
            "net_pnl": pnl.sum(),
            "avg_pnl": pnl.mean(),
            "median_pnl": pnl.median(),
            "gross_profit": gp,
            "gross_loss": gl,
            "profit_factor": profit_factor(pnl),
            "max_single_profit": pnl.max(),
            "max_single_loss": pnl.min(),
            "estimated_max_drawdown": max_drawdown(pnl)
        })
    if group_cols is None:
        return calc(data).to_frame().T
    if isinstance(group_cols, str):
        group_cols = [group_cols]
    return data.groupby(group_cols, dropna=False).apply(calc).reset_index()


def show(df_show, title=None, n=None):
    out = df_show.copy()
    for c in out.select_dtypes(include=[float]).columns:
        out[c] = out[c].round(6)
    if title:
        print("\n" + "=" * 90)
        print(title)
        print("=" * 90)
    display(out.head(n) if n else out)

# =========================
# 3. Risk tags
# =========================

rv80 = df["realized_vol_10bar"].quantile(0.8)
rd_q25 = df["entry_relative_deviation"].quantile(0.25)  # 更深負偏離
rd_q50 = df["entry_relative_deviation"].quantile(0.50)
tw50_q75 = df["tw50_return_5m"].quantile(0.75)


def is_lunch_tail_session(x):
    s = str(x)
    return (s == "午盤尾段_1245_1300") or (s == "lunch_tail_1245_1300")


def make_tags(row):
    tags = []
    pnl0 = row["pnl_no_cost"]

    if pnl0 < 0:
        tags.append("Loss_Trade")

    if pnl0 > 0 and row["pnl_cost_001_recalc"] <= 0:
        tags.append("Cost_Fragile_001")
    if pnl0 > 0 and row["pnl_cost_002_recalc"] <= 0:
        tags.append("Cost_Fragile_002")
    if pnl0 > 0 and row["pnl_slip_025tick"] <= 0:
        tags.append("Slip_Fragile_025tick")

    if str(row["exit_reason"]) == "EXIT_TIME":
        tags.append("EXIT_TIME_No_Reversion")

    if row["signal_count_today"] >= 2:
        tags.append("Repeated_Signal")

    if is_lunch_tail_session(row["session_block"]):
        tags.append("Lunch_Tail_1245_1300")

    if row["realized_vol_10bar"] >= rv80:
        tags.append("High_RV10_Top20pct")

    if str(row["data_split"]).startswith("Train") or row["entry_year"] <= 2024:
        tags.append("Train_2022_2024")

    if str(row["entry_time_hhmm"]) == "09:45":
        tags.append("Boundary_Exact_0945")

    if not tags:
        tags.append("Normal_or_Low_Risk")

    return "|".join(tags)


df["risk_tags"] = df.apply(make_tags, axis=1)

for tag in [
    "Loss_Trade", "Cost_Fragile_001", "Cost_Fragile_002", "Slip_Fragile_025tick",
    "EXIT_TIME_No_Reversion", "Repeated_Signal", "Lunch_Tail_1245_1300",
    "High_RV10_Top20pct", "Train_2022_2024", "Boundary_Exact_0945"
]:
    df["is_" + tag] = df["risk_tags"].str.contains(tag, regex=False)

# =========================
# 4. Base summaries
# =========================

overall_no_cost = perf_summary(df, "pnl_no_cost")
overall_cost001 = perf_summary(df, "pnl_cost_001_recalc")
overall_cost002 = perf_summary(df, "pnl_cost_002_recalc")
overall_slip025 = perf_summary(df, "pnl_slip_025tick")

by_split_no_cost = perf_summary(df, "pnl_no_cost", "data_split")
by_split_cost002 = perf_summary(df, "pnl_cost_002_recalc", "data_split")
by_session_no_cost = perf_summary(df, "pnl_no_cost", "session_block")
by_session_cost002 = perf_summary(df, "pnl_cost_002_recalc", "session_block")
by_exit_no_cost = perf_summary(df, "pnl_no_cost", "exit_reason")
by_exit_cost002 = perf_summary(df, "pnl_cost_002_recalc", "exit_reason")
by_signal_no_cost = perf_summary(df, "pnl_no_cost", "signal_count_today")
by_signal_cost002 = perf_summary(df, "pnl_cost_002_recalc", "signal_count_today")

show(overall_no_cost, "Overall No Cost")
show(overall_cost002, "Overall Cost 0.02")
show(by_session_cost002, "By Session Cost 0.02")
show(by_exit_cost002, "By Exit Cost 0.02")

# =========================
# 5. Tag summary and interactions
# =========================

tagged = df.copy()
tagged["risk_tag"] = tagged["risk_tags"].str.split("|")
tagged = tagged.explode("risk_tag")

tag_summary_no = perf_summary(tagged, "pnl_no_cost", "risk_tag")
tag_summary_001 = perf_summary(tagged, "pnl_cost_001_recalc", "risk_tag")
tag_summary_002 = perf_summary(tagged, "pnl_cost_002_recalc", "risk_tag")
tag_summary_slip025 = perf_summary(tagged, "pnl_slip_025tick", "risk_tag")

tag_summary = tag_summary_no[[
    "risk_tag", "trades", "net_pnl", "avg_pnl", "gross_loss", "profit_factor", "max_single_loss"
]].rename(columns={
    "trades": "tag_count",
    "net_pnl": "net_pnl_no_cost",
    "avg_pnl": "avg_pnl_no_cost",
    "gross_loss": "gross_loss_no_cost",
    "profit_factor": "pf_no_cost",
    "max_single_loss": "max_loss_no_cost"
})

tag_summary = tag_summary.merge(
    tag_summary_001[["risk_tag", "net_pnl", "profit_factor"]].rename(columns={"net_pnl": "net_pnl_cost001", "profit_factor": "pf_cost001"}),
    on="risk_tag", how="left"
).merge(
    tag_summary_002[["risk_tag", "net_pnl", "profit_factor"]].rename(columns={"net_pnl": "net_pnl_cost002", "profit_factor": "pf_cost002"}),
    on="risk_tag", how="left"
).merge(
    tag_summary_slip025[["risk_tag", "net_pnl", "profit_factor"]].rename(columns={"net_pnl": "net_pnl_slip025", "profit_factor": "pf_slip025"}),
    on="risk_tag", how="left"
).sort_values("net_pnl_cost002")

show(tag_summary, "Tag Summary")

tag_x_split_cost002 = perf_summary(tagged, "pnl_cost_002_recalc", ["risk_tag", "data_split"]).sort_values("net_pnl")
tag_x_session_cost002 = perf_summary(tagged, "pnl_cost_002_recalc", ["risk_tag", "session_block"]).sort_values("net_pnl")
tag_x_exit_cost002 = perf_summary(tagged, "pnl_cost_002_recalc", ["risk_tag", "exit_reason"]).sort_values("net_pnl")

# =========================
# 6. Scenario proxy tests
# These are diagnostics only, not final trading rules.
# =========================

scenarios = {}
scenarios["Base_v2B3"] = pd.Series(True, index=df.index)

# Lunch tail future work
scenarios["Exclude_LunchTail_diagnostic"] = ~df["is_Lunch_Tail_1245_1300"]
scenarios["LunchTail_keep_deeper_RD_only"] = (~df["is_Lunch_Tail_1245_1300"]) | (df["is_Lunch_Tail_1245_1300"] & (df["entry_relative_deviation"] <= rd_q25))
scenarios["LunchTail_keep_stronger_TW50_only"] = (~df["is_Lunch_Tail_1245_1300"]) | (df["is_Lunch_Tail_1245_1300"] & (df["tw50_return_5m"] >= tw50_q75))
scenarios["LunchTail_keep_deepRD_or_strongT5"] = (~df["is_Lunch_Tail_1245_1300"]) | (df["is_Lunch_Tail_1245_1300"] & ((df["entry_relative_deviation"] <= rd_q25) | (df["tw50_return_5m"] >= tw50_q75)))

# Repeated signal future work
scenarios["FirstSignal_only_diagnostic"] = ~df["is_Repeated_Signal"]
scenarios["Repeated_require_deeper_RD"] = (~df["is_Repeated_Signal"]) | (df["is_Repeated_Signal"] & (df["entry_relative_deviation"] <= rd_q25))
scenarios["Repeated_require_stronger_TW50"] = (~df["is_Repeated_Signal"]) | (df["is_Repeated_Signal"] & (df["tw50_return_5m"] >= tw50_q75))
scenarios["Repeated_require_deepRD_or_strongT5"] = (~df["is_Repeated_Signal"]) | (df["is_Repeated_Signal"] & ((df["entry_relative_deviation"] <= rd_q25) | (df["tw50_return_5m"] >= tw50_q75)))

# High RV / EXIT_TIME diagnostics
scenarios["Exclude_HighRV_top20_diagnostic"] = ~df["is_High_RV10_Top20pct"]
scenarios["Exclude_HighRV_and_EXIT_TIME"] = ~(df["is_High_RV10_Top20pct"] & df["is_EXIT_TIME_No_Reversion"])
scenarios["Exclude_EXIT_TIME_diagnostic_not_tradable"] = ~df["is_EXIT_TIME_No_Reversion"]
scenarios["Strict_execution_proxy_not_tradable"] = ~df["is_Slip_Fragile_025tick"]

scenario_rows = []
for name, mask in scenarios.items():
    sub = df[mask].copy()
    base = perf_summary(sub, "pnl_no_cost").iloc[0]
    c001 = perf_summary(sub, "pnl_cost_001_recalc").iloc[0]
    c002 = perf_summary(sub, "pnl_cost_002_recalc").iloc[0]
    s025 = perf_summary(sub, "pnl_slip_025tick").iloc[0]
    scenario_rows.append({
        "scenario": name,
        "trades": int(base["trades"]),
        "net_pnl_no_cost": base["net_pnl"],
        "avg_pnl_no_cost": base["avg_pnl"],
        "pf_no_cost": base["profit_factor"],
        "max_dd_no_cost": base["estimated_max_drawdown"],
        "net_pnl_cost001": c001["net_pnl"],
        "avg_pnl_cost001": c001["avg_pnl"],
        "pf_cost001": c001["profit_factor"],
        "net_pnl_cost002": c002["net_pnl"],
        "avg_pnl_cost002": c002["avg_pnl"],
        "pf_cost002": c002["profit_factor"],
        "max_dd_cost002": c002["estimated_max_drawdown"],
        "net_pnl_slip025": s025["net_pnl"],
        "pf_slip025": s025["profit_factor"],
    })

scenario_proxy = pd.DataFrame(scenario_rows).sort_values("net_pnl_cost002", ascending=False)
show(scenario_proxy, "Scenario Proxy")

scenario_by_split_list = []
for name, mask in scenarios.items():
    sub = df[mask].copy()
    tmp = perf_summary(sub, "pnl_cost_002_recalc", "data_split")
    tmp.insert(0, "scenario", name)
    scenario_by_split_list.append(tmp)
scenario_by_split = pd.concat(scenario_by_split_list, ignore_index=True)

# =========================
# 7. Casebook tables
# =========================

case_cols = [
    "trade_number", "entry_datetime", "exit_datetime", "entry_date", "entry_time_hhmm",
    "entry_year", "entry_month", "data_split", "session_block", "exit_reason",
    "signal_count_today", "holding_minutes", "pnl_no_cost", "pnl_cost_001_recalc",
    "pnl_cost_002_recalc", "pnl_slip_025tick", "risk_tags",
    "entry_relative_deviation", "tw50_return_5m", "realized_vol_10bar", "deviation_slope_1bar",
    "volume_ratio_at_entry", "mfe_twd", "mae_twd"
]
case_cols = [c for c in case_cols if c in df.columns]

worst_loss_base = df[case_cols].sort_values("pnl_no_cost").head(30)
worst_loss_cost002 = df[case_cols].sort_values("pnl_cost_002_recalc").head(30)
cost_fragile_cases = df[df["is_Cost_Fragile_001"] | df["is_Cost_Fragile_002"] | df["is_Slip_Fragile_025tick"]][case_cols].sort_values("pnl_no_cost")
exit_time_cases = df[df["is_EXIT_TIME_No_Reversion"]][case_cols].sort_values("pnl_cost_002_recalc")
repeated_cases = df[df["is_Repeated_Signal"]][case_cols].sort_values("pnl_cost_002_recalc")
lunch_tail_cases = df[df["is_Lunch_Tail_1245_1300"]][case_cols].sort_values("pnl_cost_002_recalc")
highrv_cases = df[df["is_High_RV10_Top20pct"]][case_cols].sort_values("pnl_cost_002_recalc")

# =========================
# 8. Diagnostics and conclusion
# =========================

diagnostics = pd.DataFrame({
    "item": [
        "input_file", "rows_should_be_223", "net_pnl_should_be_about_7_80",
        "rd_q25", "tw50_q75", "rv80", "unique_exit_reason", "unique_session_block"
    ],
    "value": [
        file_name, len(df), round(df["pnl_no_cost"].sum(), 4),
        rd_q25, tw50_q75, rv80,
        ", ".join(map(str, sorted(df["exit_reason"].dropna().unique()))),
        ", ".join(map(str, sorted(df["session_block"].dropna().unique())))
    ]
})

conclusion = pd.DataFrame({
    "conclusion": [
        "This output is for high-risk sample review, not v2-C.",
        "Use Tag_Summary to identify whether remaining risk is cost, exit, repeated signal, lunch tail, or high volatility related.",
        "Use Scenario_Proxy only as diagnostic future-work evidence, not as final strategy selection.",
        "If a scenario improves cost-adjusted results but removes too many trades or uses future-known fields such as exit_reason, keep it as Future Work only.",
        "v2-B3 should remain final signal candidate unless a future execution-aware version passes separate path-dependent TradingView backtest."
    ]
})

# =========================
# 9. Export
# =========================

with pd.ExcelWriter(OUTPUT_FILE, engine="openpyxl") as writer:
    diagnostics.to_excel(writer, sheet_name="Diagnostics", index=False)
    df.to_excel(writer, sheet_name="Parsed_Events_With_Tags", index=False)

    overall_no_cost.to_excel(writer, sheet_name="Overall_NoCost", index=False)
    overall_cost001.to_excel(writer, sheet_name="Overall_Cost001", index=False)
    overall_cost002.to_excel(writer, sheet_name="Overall_Cost002", index=False)
    overall_slip025.to_excel(writer, sheet_name="Overall_Slip025", index=False)

    by_split_no_cost.to_excel(writer, sheet_name="By_Split_NoCost", index=False)
    by_split_cost002.to_excel(writer, sheet_name="By_Split_Cost002", index=False)
    by_session_no_cost.to_excel(writer, sheet_name="By_Session_NoCost", index=False)
    by_session_cost002.to_excel(writer, sheet_name="By_Session_Cost002", index=False)
    by_exit_no_cost.to_excel(writer, sheet_name="By_Exit_NoCost", index=False)
    by_exit_cost002.to_excel(writer, sheet_name="By_Exit_Cost002", index=False)
    by_signal_no_cost.to_excel(writer, sheet_name="By_Signal_NoCost", index=False)
    by_signal_cost002.to_excel(writer, sheet_name="By_Signal_Cost002", index=False)

    tag_summary.to_excel(writer, sheet_name="Tag_Summary", index=False)
    tag_x_split_cost002.to_excel(writer, sheet_name="Tag_x_Split_Cost002", index=False)
    tag_x_session_cost002.to_excel(writer, sheet_name="Tag_x_Session_Cost002", index=False)
    tag_x_exit_cost002.to_excel(writer, sheet_name="Tag_x_Exit_Cost002", index=False)

    scenario_proxy.to_excel(writer, sheet_name="Scenario_Proxy", index=False)
    scenario_by_split.to_excel(writer, sheet_name="Scenario_By_Split", index=False)

    worst_loss_base.to_excel(writer, sheet_name="Worst_Loss_Base", index=False)
    worst_loss_cost002.to_excel(writer, sheet_name="Worst_Loss_Cost002", index=False)
    cost_fragile_cases.to_excel(writer, sheet_name="Cost_Fragile_Cases", index=False)
    exit_time_cases.to_excel(writer, sheet_name="EXIT_TIME_Cases", index=False)
    repeated_cases.to_excel(writer, sheet_name="Repeated_Cases", index=False)
    lunch_tail_cases.to_excel(writer, sheet_name="Lunch_Tail_Cases", index=False)
    highrv_cases.to_excel(writer, sheet_name="HighRV_Cases", index=False)

    conclusion.to_excel(writer, sheet_name="Conclusion", index=False)

print("Done. Exported:", OUTPUT_FILE)
files.download(OUTPUT_FILE)
