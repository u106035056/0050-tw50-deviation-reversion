# 0050 v2-B3 High Risk Review Ready Package

## 你要上傳到 Colab 的檔案

只上傳這個：

`UPLOAD_THIS_TO_COLAB__v2B3_Parsed_B3_Events_223.csv`

這是我從 `0050_v2B3_final_stratified_review_outputs.xlsx` 的 `Parsed_B3_Events` sheet 抽出的乾淨 223 筆 event dataset。

## 不要上傳

- TradingView raw CSV：會變成 446 行，不是 223 筆 event。
- 前一次 high risk output：那是輸出檔，不是輸入檔。
- B1/B2 CSV：這次研究是 v2-B3，不用它們。

## 正確檢查點

跑完後 Diagnostics 應該接近：

- rows_should_be_223 = 223
- net_pnl_should_be_about_7_80 ≈ 7.80
- exit_reason 不應該是 Unknown_Raw_CSV
- session_block 不應該全是 Unknown

## 跑完後回傳

請回傳：

`0050_v2B3_high_risk_sample_review_outputs_READY.xlsx`

我會幫你整理成：主結論、Known Limitations、Future Work。
